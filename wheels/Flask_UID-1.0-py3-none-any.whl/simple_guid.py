from flask import app
import uuid
class UIDGenerator(object):

    def __init__(self,app):
        pass

    def get_uid(self):
        return uuid.uuid1()

